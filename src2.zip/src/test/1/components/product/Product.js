// const Product=(props)=>{
//     return (<div>{props.title}</div>)
// }

// Or
const Product=({title})=>{
    return (<div>{title}</div>)
}
export default Product;