import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import CountryStateButton from "./countryStateButton/CountryStateButton";

export default function ModelLocation(props) {
    return (<Modal className="right-to-left"
                   {...props}
                   size="lg"
                   aria-labelledby="contained-modal-title-vcenter"
                   centered>

            {/*<Modal.Header closeButton right-to-left>*/}
            {/*    <Modal.Title id="contained-modal-title-vcenter">*/}
            {/*        انتخاب شهر*/}
            {/*    </Modal.Title>*/}
            {/*</Modal.Header> */}
            <Modal.Header right-to-left>
                <Modal.Title id="contained-modal-title-vcenter">
                    انتخاب شهر
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>

                <ul className="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <CountryStateButton id="" text="آذربایجان"/>
                    <CountryStateButton id="" text="اردبیل"/>
                    <CountryStateButton id="" text="تهران"/>
                    <CountryStateButton id="" text=""/>
                    <CountryStateButton id="" text=""/>
                    <CountryStateButton id="" text=""/>
                </ul>
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={props.onHide}>انتخاب</Button>
                <Button onClick={props.onHide}>انصراف</Button>
            </Modal.Footer>
        </Modal>);
}


