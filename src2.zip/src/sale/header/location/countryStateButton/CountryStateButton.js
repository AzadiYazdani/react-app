import './CountryStateButton.css';
import arrow from '../../../../resource/baseline-keyboard-arrow-left.svg'
export default function CountryStateButton(props) {

    return (
        <div>
            <div>
                <li><a className="nav-link" href="#!">{props.text}</a></li>
                <hr className="hr-divider"/>
            </div>
            <div className="kt-base-row__end">
                <i className="kt-icon kt-icon-keyboard-arrow-left kt-icon--lg kt-base-row__arrow">arrow</i>
            </div>
        </div>
    );
}
